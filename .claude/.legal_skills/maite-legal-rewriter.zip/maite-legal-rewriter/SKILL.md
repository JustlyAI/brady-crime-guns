---
name: maite-legal-rewriter
description: Transform draft legal documents into polished, elite Big Law quality work product. Use when rewriting or refining any legal document including expert comparison reports, witness briefs, deposition questions, legal memos, or any document that needs professional legal polish. Applies Maite's exacting standards for paragraph construction, citation practice, analytical depth, and professional tone.
---

# Legal Document Rewriter

Transform draft content into elite Big Law quality work product.

## Rewrite Workflow

Execute these phases in order. Do not skip steps.

### Phase 1: Draft Analysis

Read the draft document completely. Identify:

1. **Document Type** — What kind of document is this?
   - Expert comparison report
   - Witness brief (defense preparation)
   - Deposition questions (cross-examination or defense)
   - Legal memo
   - Other (describe)

2. **Current State** — What needs improvement?
   - Structure issues (missing sections, wrong order)
   - Style issues (bullet lists instead of prose, weak transitions)
   - Citation gaps (claims without sources)
   - Tone problems (advocacy language, hedging, hyperbole)

3. **Scope** — What is being asked?
   - Full rewrite vs. targeted polish
   - Which sections need most work

### Phase 2: Load Guidelines

Based on document type, read the relevant reference:

| Document Type | Reference |
|---------------|-----------|
| Expert comparison reports | `references/comparison-reports.md` |
| Witness briefs, deposition questions | `references/expert-depo-prep.md` |
| All documents | `references/core-style.md` (always read this) |

**Always read `core-style.md`.** It contains universal principles.

### Phase 3: Context Immersion

Before rewriting, develop deep understanding of all provided context:

1. **Read everything provided** — Source documents, prior drafts, exhibits, expert reports
2. **Note key facts** — Names, dates, amounts, document citations
3. **Understand the matter** — What's the case about? Who are the parties?
4. **Identify the audience** — Who will use this document? For what purpose?

**Do not proceed until you understand the context cold.** The rewrite quality depends on contextual understanding.

### Phase 4: Rewrite Plan

Before writing, plan the transformation:

```markdown
## Rewrite Plan

**Document Type:** [type]
**Target Length:** [estimate]

**Structural Changes:**
- [change 1]
- [change 2]

**Style Corrections:**
- [issue 1] → [fix]
- [issue 2] → [fix]

**Citation Gaps to Address:**
- [claim needing source]

**Sections Requiring Most Work:**
1. [section]
2. [section]
```

### Phase 5: Execute Rewrite

Write the transformed document applying all guidelines.

**Key transformations:**
- Convert bullet lists to complete paragraphs
- Add substantive transitions between sections
- Insert citations for every factual claim
- Replace hyperbole with precise language
- Add classification headers and professional formatting
- Ensure every table has a purpose
- Verify tone is analytical, not advocacy

### Phase 6: Self-Review

Before delivering, check:

- [ ] Every factual claim has a citation
- [ ] No bullet lists used for analysis (prose only)
- [ ] Opening sentences lead with the point
- [ ] Transitions are substantive, not generic
- [ ] No advocacy language or hyperbole
- [ ] Classification block present
- [ ] Tables used for data only, not reasoning
- [ ] Length appropriate for document type

---

## Quick Reference: Common Transformations

### Bullets → Prose

**Before:**
> Key issues:
> - Schedule failed DCMA standards
> - Manpower 52% below requirement
> - Cost overrun of 108%

**After:**
> Gaudion's own appendices undermine his conclusions on three fronts. Appendix F documents that the schedule failed DCMA standards by 900%. Appendix I shows Period 4 manpower at 52% below contract requirements. And Appendix K reveals a 108% cost overrun on general conditions—Suffolk spent more than double their budget while claiming to perform efficiently.

### Hedging → Decisive

**Before:**
> It could potentially be argued that A3 might have a somewhat stronger position on the delay issues.

**After:**
> Our assessment is that A3 holds the stronger position on the delay issues.

### Generic → Substantive Transitions

**Before:**
> Additionally, the manpower data shows problems. Furthermore, the cost data is also concerning.

**After:**
> The manpower decline tells one story; the cost overrun tells another. Together, they contradict the efficient contractor narrative.

### Missing → Cited

**Before:**
> Gaudion's analysis is flawed because the schedule was unreliable.

**After:**
> Gaudion's Appendix F documents that Suffolk's baseline schedule contained 44.5% high-float activities against a DCMA threshold of 5%—a 900% exceedance. Analysis built on a schedule that fails industry standards by this margin produces unreliable results.

---

## References

This skill includes document-type-specific guidelines:

- **`references/core-style.md`** — Universal writing principles (always read)
- **`references/comparison-reports.md`** — Expert comparison report structure and standards
- **`references/expert-depo-prep.md`** — Witness briefs and deposition question formats
