# Expert Comparison Report Guidelines

Comprehensive analysis comparing two or more expert positions. Used for trial preparation, settlement discussions, and attorney decision-making.

---

## Document Structure

```
1. Executive Summary
   1.1 Financial Summary (table: amounts at stake)
   1.2 Top-Line Findings (who has stronger position, why)
   1.3 Preparation Priorities (table: issue, priority, required action)

2. The Experts and Their Methodologies
   2.1 Expert Background (qualifications, reports filed, appendices)
   2.2 Fundamental Methodological Difference (what question each answers)
   2.3 Assessment of the Methodologies (strengths/weaknesses)

3. Analysis of Key Issues (largest section)
   3.1 [Issue One]
   3.2 [Issue Two]
   ... (one subsection per contested issue)

4. Opposing Arguments and Responses
   4.1 "[Opposing Argument 1]"
   4.2 "[Opposing Argument 2]"
   ... (anticipate and pre-rebut)

5. Appendix Admissions (if applicable)
   - Document where opposing expert's own exhibits undermine their conclusions

6. Financial Analysis
   - Tables with amounts, caps, scenarios

7. Recommendations
   7.1 Deposition Preparation
   7.2 Trial Exhibits
   7.3 Outstanding Verification Items
```

---

## Executive Summary Standards

**Financial Summary Table:**
```markdown
| Outcome | Amount |
|---------|--------|
| **If [Party A] Prevails** | $X,XXX,XXX |
| **If [Party B] Prevails** | $Y,YYY,YYY |
| **Total Swing** | ~$Z,ZZZ,ZZZ |
```

**Assessment Statement:**
Open with clear position: "Our assessment is that [Party] holds the stronger position on [issues]."
Then provide 3 principal grounds with citations.

**Preparation Priorities Table:**
```markdown
| Priority | Issue | Required Action |
|----------|-------|-----------------|
| **CRITICAL** | [Issue] | [Specific action verb + what to do] |
| **HIGH** | [Issue] | [Specific action verb + what to do] |
| **MEDIUM** | [Issue] | [Specific action verb + what to do] |
```

---

## Issue Analysis Format

Each issue section follows this pattern:

```markdown
### 3.X [Issue Name]

[Opening paragraph: Why this issue matters, what's at stake]

**[Expert A]'s Position:** [Summary with citations]
- [Key point 1]
- [Key point 2]

**[Expert B]'s Position:** [Summary with citations]
- [Key point 1]
- [Key point 2]

**Analysis:** [Your assessment of the merits. Complete paragraphs.
This is where you provide the lawyer's judgment. Don't hedge.
Explain reasoning. Note what the factfinder will likely find
persuasive and why.]

**Preparation Note:** [If applicable: what trial team should do
with this issue]
```

---

## Writing Standards

### Paragraph Construction

**Never bullet points for analysis.** Use complete, flowing paragraphs.

Good:
> The 96.3% allocation presents a credibility challenge. According to Gaudion's analysis, Suffolk—a contractor that was terminated for cause after achieving only 1.5 of 19 contractual milestones—bore only 3.7% responsibility for a project that ran more than two years behind schedule. Thirteen of his 21 milestone calculations show zero or negative contractor fault.

Bad:
> - 96.3% allocation has credibility issues
> - Only 1.5 of 19 milestones achieved
> - 13 of 21 calculations show zero/negative fault

### Transitions

Use substantive transitions, not generic connectors:

Good:
> "This distinction matters because it is objective and verifiable."
> "The relevant question is not what the average was, but what happened in the months leading to termination."

Bad:
> "Additionally..."
> "Furthermore..."
> "Moreover..."

### Tables vs. Prose

**Use tables for:**
- Financial summaries
- Preparation priorities
- Document citations in lists
- Side-by-side comparisons of specific figures

**Use prose for:**
- Analysis and assessment
- Explaining why something matters
- Credibility arguments
- Recommendations

### Citation Practice

Cite to paragraph numbers, appendices, and exhibits:
- "Gaudion's Executive Summary at paragraph 10a states..."
- "Per Appendix F, which documents DCMA compliance..."
- "Rebuttal Figures 1-5 contain email evidence showing..."

### Tone

**Objective but decisive.** This is analysis for attorneys, not advocacy for tribunal.

- State conclusions clearly: "Our assessment is..." not "It could be argued..."
- Acknowledge weaknesses: "That said, the trial team should be aware..."
- Provide judgment: "The 96.3% allocation strains credulity" (if true)

### Classification and Headers

Every report must include:
```markdown
**Matter:** [Case Name] ([Matter Number])
**Prepared for:** [Audience]
**Date:** [Date]
**Classification:** Attorney Work Product — Privileged and Confidential
```

---

## What NOT to Include

- Advocacy language ("devastating," "crushing," "annihilates")
- Confidence scores or numerical ratings of positions
- Speculation beyond what documents support
- Case strategy beyond the analysis scope
- Recommendations that exceed analyst role (e.g., settlement advice)
