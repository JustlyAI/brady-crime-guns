# Core Legal Writing Style

Principles that apply to all legal document types.

---

## The Maite Standard

Elite Big Law quality. Clear, persuasive, precise. Every sentence earns its place.

---

## Paragraph Construction

### Complete Paragraphs, Not Bullet Lists

Analysis requires prose. Bullets are for lists of items, not explanation of reasoning.

**Example — Good:**
> Biddle's methodology has the advantage of objectivity. His LDs calculations rest on undisputed TCO dates issued by the City of Sunny Isles Beach. His 160-day concurrent credit demonstrates a willingness to give Suffolk credit where documentation supports it. The principal criticism of his approach—that he did not perform a traditional CPM analysis—is addressed by his Rebuttal's explanation that the baseline schedule was too unreliable to support such analysis, a point validated by Gaudion's own Appendix F.

**Example — Bad:**
> Biddle's methodology advantages:
> - Objective (based on TCO dates)
> - Gives credit where due (160 days)
> - Explains why no CPM analysis
> - Supported by Gaudion's Appendix F

### Paragraph Unity

One topic per paragraph. If you change subjects, start a new paragraph.

### Opening Sentences

Lead with the point. Don't bury it.

**Good:** "This inconsistency is never acknowledged or reconciled in Gaudion's reports."

**Bad:** "When examining the various sections of Gaudion's reports, one notices that this inconsistency is never acknowledged."

---

## Sentence Construction

### Sentence Length

Vary length. Mix short declarative sentences with longer explanatory ones.

**Good:**
> The 8-week data gap before termination is suspicious. If staffing was adequate, why is the data missing for the most critical period?

**Bad:**
> The 8-week data gap before termination, which occurs during what would be considered the most critical period of the project and during which one would expect staffing data to be especially well-documented if it were adequate, is suspicious.

### Active Voice

Use active voice for clarity and attribution.

**Good:** "Gaudion calculates that Suffolk bears only 3.7% responsibility."

**Bad:** "It was calculated by Gaudion that only 3.7% responsibility is borne by Suffolk."

### Avoid Nominalizations

Use verbs, not noun forms of verbs.

**Good:** "Suffolk failed to meet milestones."

**Bad:** "The failure of Suffolk to achieve milestone completion occurred."

---

## Word Choice

### Precision Over Emphasis

Choose precise words rather than emphatic modifiers.

**Good:** "The schedule failed DCMA standards by 900%."

**Bad:** "The schedule catastrophically failed DCMA standards by a massive 900%."

### No Hyperbole

Never use: devastating, crushing, annihilates, destroys, fatal, killer, bombshell

Instead: strong, significant, damaging, undermines, contradicts, refutes

### Legal Terms

Use correctly. When in doubt, use plain English.

**Correct usage:**
- "Impeach with [document]" (challenge credibility using evidence)
- "Contemporaneous" (at the time, not retrospective)
- "Work product" (attorney analysis, not discoverable)

### Avoid Filler

Remove: indeed, in fact, clearly, obviously, it should be noted that, it is important to note

If something is clear or obvious, the reader will see it.

---

## Citation Practice

### Every Factual Claim Needs a Source

Not: "Gaudion's analysis is flawed."

But: "Gaudion's Appendix F documents that Suffolk's baseline schedule contained 44.5% high-float activities against a DCMA threshold of 5%—a 900% exceedance."

### Citation Format

Use parenthetical or inline citations:
- "Gaudion's Executive Summary at paragraph 10a states..."
- "(Rebuttal Section 4.3.2.1)"
- "Per Appendix F..."
- "See Biddle Report Part 3, Figure 100."

### Specificity

Cite to the most specific location possible:
- Paragraph numbers over page numbers
- Table/Figure numbers when available
- Appendix + subsection

---

## Document Headers

### Classification Block (Every Document)

```markdown
**Matter:** [Case Name] ([Matter Number])
**[Role/Purpose]:** [Description]
**Date:** [Date]
**Classification:** [Privileged/Confidential as appropriate]
```

### Section Numbering

Use decimal numbering for nested sections:
```
1. Section
   1.1 Subsection
   1.2 Subsection
2. Section
   2.1 Subsection
```

### Tables

Use tables for:
- Structured data (dates, amounts, names)
- Side-by-side comparisons
- Preparation priorities with action items
- Document lists

Never use tables for analysis or reasoning.

---

## Tone

### Objective But Decisive

State conclusions clearly. Don't hedge when the analysis supports a position.

**Good:** "Our assessment is that A3 holds the stronger position."

**Bad:** "It could potentially be argued that A3 might have a somewhat stronger position."

### Acknowledge Weaknesses

Credibility comes from balance. Note preparation needs.

**Good:** "That said, the trial team should be aware of several areas requiring preparation before depositions."

### No Advocacy

This is analysis for attorneys, not argument for tribunal.

**Inappropriate:** "The tribunal should find for A3."

**Appropriate:** "A3 holds the stronger position because..."

---

## Common Errors to Avoid

1. **Bullet lists for analysis** — Use prose
2. **Generic transitions** — Use substantive connectors
3. **Buried leads** — Open with the point
4. **Hedging supported conclusions** — Be decisive
5. **Missing citations** — Every claim needs a source
6. **Advocacy language** — Stay in analyst role
7. **Confidence scores** — Use qualitative assessments
8. **Overclaiming** — If uncertain, say so and note what to verify
