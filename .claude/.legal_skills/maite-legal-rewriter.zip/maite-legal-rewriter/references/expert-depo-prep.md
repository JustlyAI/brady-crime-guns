# Expert Deposition Preparation Guidelines

This reference covers two document types:
1. **Witness Brief** — Preparation memo for defending your expert
2. **Deposition Questions** — Cross-examination questions for opposing experts

---

## Witness Brief (Defense Preparation)

### Document Structure

```
1. Executive Summary (1 page)
   - Witness overview (role, qualifications, reports filed)
   - Key opinions (3-5 bullet points)
   - Top 3 strengths (why this expert is credible)
   - Top 3 preparation priorities (what needs work before deposition)

2. Complete Position (2-3 pages)
   - Methodology description (clear, defensible explanation)
   - Key findings with citations
   - Calculations or quantifications with sources

3. Known Attacks & Defenses (2-3 pages per attack)
   - Attack description with risk level (HIGH/MEDIUM/LOW)
   - Defense strategy (how to respond)
   - Documentary support (what documents back the defense)
   - Sound bite (memorable one-liner)

4. Gap Analysis (0.5 page)
   - Arguments opposing counsel did not respond to (our strengths)
   - Attacks our expert did not address (preparation needs)

5. Preparation Priorities (1 page)
   - Critical items to verify (with specific action items)
   - Hard questions to master (with recommended responses)
```

### Writing Standards

**Risk Level Assignments:**
- HIGH: Factual accuracy disputed, could undermine core conclusions
- MEDIUM-HIGH: Significant challenge, requires strong response
- MEDIUM: Contested but manageable with preparation
- LOW: Minor issue, unlikely to affect credibility

**Defense Strategy Format:**
```markdown
**Defense Strategy:**
- Lead with [strongest point]
- Pivot to [offensive counterpoint]
- If challenged further: [fallback position]
```

**Sound Bites:**
- 10-15 words maximum
- Memorizable and quotable
- Substance over cleverness ("I verified; he assumed" not wordplay)
- Must be accurate (never sound bite a disputed fact)

**Hard Questions Format:**
```markdown
**"[Question opposing counsel will ask verbatim]"**
Response: "[Full response for witness to study/adapt]"
```

---

## Deposition Questions (Cross-Examination)

### Document Structure

```
Part 1: Cross-Examination Questions (Opposing Expert)
  1.1 Internal Inconsistency Attacks
  1.2 Appendix/Exhibit Admissions
  1.3 Uncontested Evidence
  1.4 Methodology Attacks
  1.5 Specific Issue Attacks
  1.6 Credibility Questions

Part 2: Preparation Questions (Your Expert)
  2.1 Anticipated Attacks and Responses
  2.2 Hard Questions to Master
  2.3 Documents to Have Ready

Summary: Key Deposition Objectives (closing themes)
```

### Question Format (Cross-Examination)

Each question must be stand-alone. Lawyers pick individual questions, not chains.

```markdown
#### Question N: [Descriptive Title]

**Question:** "[Exact question to ask, in quotes]"

- **Target Issue:** [What this question proves]
- **Setup Documents:** [Documents to show before asking]
- **Expected Response:** [What witness will likely say]
- **Follow-up:** "[If witness gives expected response, ask this]"
```

### Question Format (Defense Preparation)

```markdown
#### Attack N: [Attack Description]

**Anticipated Question:** "[Question opposing counsel will ask]"

**Recommended Response:**
"[Full narrative response for witness to study. Complete sentences.
Multiple paragraphs if needed. This is what the witness should say,
adapted to their own words.]"

**Documentary Support:**
- [Document 1 with specific citation]
- [Document 2 with specific citation]

**Sound Bite:** "[Memorable one-liner version]"
```

### Cross-Examination Principles

**Opening Strategy:**
- Lead with strongest attack (internal inconsistency, mathematical impossibility)
- Establish unreliability before challenging substance

**Using Their Own Documents:**
- Impeachment from expert's own appendices is most powerful
- "Your Appendix [X] shows [damaging fact]. How do you reconcile that with [conclusion]?"

**Closing Questions:**
- End on credibility: "Given [list of problems], why should this tribunal credit your conclusion?"
- Have a closing theme ready (2-3 sentences summarizing the attack)

### What NOT to Include

- Witness coaching or demeanor guidance ("maintain eye contact")
- "Do Not Say" lists (attorney work product, not analyst deliverable)
- Case strategy beyond the immediate deposition
- Speculative objections or procedural notes
