# Opposition Analysis Checklist

Systematic checklist for analyzing opposition briefs to motions to dismiss.

## Document Review

### Opening Brief Review
- [ ] Identified all claims challenged
- [ ] Noted legal standards cited
- [ ] Listed key cases relied upon
- [ ] Noted page/word count for reply limit calculation

### Opposition Brief Review
- [ ] Read cover to cover without skipping
- [ ] Noted total page count
- [ ] Identified table of contents structure
- [ ] Marked passages requiring response

## Argument Mapping

### For Each Opposition Argument

| Field | Required | Example |
|-------|----------|---------|
| Argument ID | Yes | OPP-1, OPP-2, etc. |
| Summary | Yes | 1-2 sentence description |
| Opening Brief Reference | Yes | "Responds to Opening at 5-7" |
| Cases Cited | Yes | List all authorities |
| Strength Assessment | Yes | Strong/Moderate/Weak |
| Vulnerability | Yes | How to attack |
| Priority | Yes | Must/Should/Ignore |

### Strength Assessment Criteria

**Strong (binding authority):**
- Cites controlling circuit precedent
- Facts closely analogous to case
- Clear application of rule

**Moderate (persuasive):**
- District court decisions from same district
- Out-of-circuit authority
- Distinguishable but arguable analogy

**Weak (distinguishable):**
- Factually dissimilar
- Dicta rather than holding
- Superseded or questioned authority

## Concession Hunting

### Explicit Concession Signals

Search for these phrases:
- "Plaintiff does not dispute..."
- "Defendant correctly notes..."
- "As the motion states..."
- "Plaintiff agrees that..."
- "It is true that..."
- "Plaintiff acknowledges..."

### Implicit Concession Signals

Look for:
- Arguments from complaint not defended
- Opening arguments not addressed at all
- Authorities cited in opening not distinguished
- Facts alleged in opening not contested
- Retreat to weaker position than complaint asserted

### Concession Documentation

For each identified concession:

```markdown
> "[Exact quote from opposition]" (Opp. at [page])

**Type:** Explicit / Implicit
**Significance:** [Why this matters for the motion]
**Confidence:** High / Medium
**Explanation:** [Why this confidence level]
```

**High Confidence:** Direct admission, clear language, no ambiguity
**Medium Confidence:** Arguable interpretation, implicit from omission

## Standard of Review Analysis

### Twombly/Iqbal Two-Step Framework

**Step 1:** Identify allegations that are conclusory (legal conclusions)
**Step 2:** Accept remaining well-pleaded factual allegations as true and assess plausibility

### Common Opposition Errors

| Error | Correct Statement |
|-------|-------------------|
| "Plaintiff need only show possibility" | Plausibility required, not mere possibility |
| "All inferences in plaintiff's favor" | Only reasonable inferences from well-pleaded facts |
| "Liberal pleading standard" | Twombly/Iqbal tightened Conley standard |
| Ignoring Rule 9(b) for fraud claims | Heightened particularity required |

### Circuit-Specific Variations

Note any circuit-specific pleading standards or precedent that applies.

## Leave to Amend Analysis

### Factors to Evaluate

**Futility (most important for reply):**
- Would proposed amendment state a claim?
- What additional facts could be alleged?
- Do public records contradict plaintiff's theory?

**Prior Amendment History:**
- How many amendments already?
- Were prior amendments to cure same deficiency?
- Did court previously give leave with guidance?

**Foman v. Davis Factors:**
- Undue delay
- Bad faith or dilatory motive
- Repeated failure to cure
- Undue prejudice to defendant
- Futility of amendment

### Reply Strategy for Leave to Amend

If opposition requests leave to amend:
- Address futility specifically
- Note prior amendment opportunities
- Argue no new facts would cure deficiencies
- Reference any judicial admissions that foreclose amendment

## Prioritization Matrix

### Must Respond (Priority 1)

Criteria (any applies):
- Opposition's strongest argument
- Court most likely to credit
- Supported by binding authority
- Goes to core of motion

### Should Respond (Priority 2)

Criteria:
- Moderate strength argument
- Worth brief treatment
- Might influence outcome if unopposed

### Ignore (No Response)

Criteria (any applies):
- Clearly weak or frivolous
- Peripheral to core issues
- Actually supports movant's position
- Response would elevate it unduly

## Output Checklist

Before finalizing analysis:

- [ ] All opposition arguments catalogued
- [ ] Each argument mapped to opening brief
- [ ] Strength assessment for each argument
- [ ] Priority assigned to each argument
- [ ] All concessions documented with quotes and cites
- [ ] Standard of review checked for accuracy
- [ ] Leave to amend analysis complete
- [ ] Recommended reply structure drafted
