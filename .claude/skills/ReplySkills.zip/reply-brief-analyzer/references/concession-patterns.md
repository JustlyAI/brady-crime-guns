# Concession Patterns in Opposition Briefs

Reference guide for identifying explicit and implicit concessions in opposition briefs to motions to dismiss.

## Why Concessions Matter

Concessions in opposition briefs are strategic gold:
- Narrow the issues for reply
- Provide ammunition for oral argument
- Can be binding judicial admissions
- Show weakness in plaintiff's position

**Citation format:** Always quote directly with page citation: `"[quote]" (Opp. at [page])`

## Explicit Concession Language

### Direct Admissions

| Pattern | Example | Significance |
|---------|---------|--------------|
| "Plaintiff does not dispute..." | "Plaintiff does not dispute that the contract requires written notice." | Direct concession of fact or legal point |
| "Defendant correctly notes..." | "Defendant correctly notes that the statute requires intent." | Validates defendant's legal argument |
| "It is true that..." | "It is true that plaintiff did not file within 30 days." | Admission against interest |
| "Plaintiff acknowledges..." | "Plaintiff acknowledges the complaint does not allege reliance." | Concession of pleading deficiency |
| "As the motion states..." | "As the motion states, the contract is unambiguous." | Adoption of defendant's position |

### Qualified Concessions

| Pattern | Example | How to Use |
|---------|---------|------------|
| "While [concession], [but]..." | "While plaintiff's claim is time-barred, equitable tolling applies." | Strip away the "but" and use the concession |
| "Even assuming..." | "Even assuming the contract is enforceable..." | Opposition concedes for argument |
| "Regardless of..." | "Regardless of whether notice was deficient..." | Implicit concession of the point |
| "Setting aside..." | "Setting aside the statute of limitations issue..." | Abandonment of defense |

### Scope-Limiting Language

| Pattern | Example | Significance |
|---------|---------|--------------|
| "With respect to Count I only..." | "With respect to Count I only, plaintiff concedes..." | Partial concession |
| "For purposes of this motion..." | "For purposes of this motion, plaintiff does not dispute..." | Tactical concession for 12(b)(6) |
| "At this stage..." | "At this stage, plaintiff cannot dispute that..." | Concession limited to pleading phase |

## Implicit Concession Patterns

### Arguments Not Made

**Pattern:** Opening brief raises argument X; opposition is silent on X.

**Analysis:**
- Compare opening brief table of contents to opposition
- Note any arguments completely unaddressed
- Treat as implicit concession unless clearly inadvertent

**Confidence level:** Medium (could be strategic choice or oversight)

### Authorities Not Distinguished

**Pattern:** Opening brief cites Case A as controlling; opposition ignores Case A.

**Analysis:**
- If Case A is binding and opposition fails to distinguish, argue they cannot
- Note: "Plaintiff does not address [Case A], apparently conceding it governs"

**Confidence level:** High if binding authority; Medium if persuasive

### Retreat from Complaint

**Pattern:** Complaint alleges X; opposition defends on narrower ground Y.

**Analysis:**
- Plaintiff's litigation position has narrowed
- Original claim effectively abandoned
- Reply can note the retreat

**Example:** Complaint alleges fraud; opposition defends only as negligent misrepresentation.

**Confidence level:** High (deliberate narrowing)

### Facts Not Contested

**Pattern:** Opening brief states fact Z (from public record); opposition does not dispute.

**Analysis:**
- Treat as admitted for purposes of motion
- But verify fact is actually undisputed
- Can be used in reply: "Plaintiff does not dispute that..."

**Confidence level:** Medium to High depending on nature of fact

## Confidence Level Guidelines

### High Confidence

Assign "High" when:
- Language is explicit and unambiguous
- No reasonable alternative interpretation
- Concession is central to opposition's argument
- Would be unreasonable to retract

### Medium Confidence

Assign "Medium" when:
- Concession is implicit from omission
- Language could be interpreted different ways
- Strategic ambiguity possible
- Minor or peripheral point

### When to Downgrade

Reduce confidence when:
- Context suggests different meaning
- Opposition made same concession sarcastically
- Word limits may explain omission
- Opposing counsel may have simply erred

## Using Concessions in Reply

### Framing Language

**For explicit concessions:**
- "Plaintiff concedes that..." (direct quote follows)
- "As plaintiff admits..." (quote follows)
- "Plaintiff's own opposition acknowledges..." (quote follows)

**For implicit concessions:**
- "Plaintiff does not dispute that..." (cite opening argument not addressed)
- "Plaintiff offers no response to..." (note unanswered authority)
- "Notably, plaintiff abandons..." (note retreat from complaint position)

### Strategic Placement

- **Introduction:** Lead with strongest concession as hook
- **Argument sections:** Use concessions to narrow issues
- **Conclusion:** Summarize key concessions as reasons to grant motion

### Avoiding Overreach

**Do:**
- Quote exactly and cite page
- Acknowledge scope limitations ("for purposes of this motion")
- Present in proper context

**Don't:**
- Overstate scope of concession
- Quote out of context
- Characterize qualified concessions as absolute
- Ignore limiting language

## Documentation Template

For each identified concession:

```markdown
### Concession: [Topic]

**Type:** Explicit / Implicit

**Quote:**
> "[Exact language from opposition]" (Opp. at [page])

**Context:** [Surrounding context if relevant]

**Significance for Reply:**
[How this helps the motion]

**Confidence:** High / Medium

**Confidence Explanation:**
[Why this confidence level]

**Recommended Use:**
[Where/how to deploy in reply]
```
