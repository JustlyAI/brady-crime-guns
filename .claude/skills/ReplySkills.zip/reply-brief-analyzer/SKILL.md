---
name: reply-brief-analyzer
description: "Analyze opposition briefs to prepare reply strategy for motions to dismiss. Use when: (1) analyzing an opposition to a motion to dismiss, (2) preparing reply strategy after receiving opposition brief, (3) identifying concessions and admissions in opposition filings, (4) mapping opposition arguments to opening brief positions, (5) prioritizing which opposition arguments to address. Requires both opening brief and opposition brief as input. Triggers on: 'analyze opposition', 'prepare reply', 'opposition concessions', 'reply strategy'."
---

# Reply Brief Analyzer

Analyze opposition briefs to motions to dismiss and generate strategic reply outlines.

## Workflow

### Phase 1: Document Intake

1. Read the opening motion to dismiss completely
2. Read the opposition brief completely
3. Note any exhibits or attachments referenced

### Phase 2: Opposition Argument Extraction

For each argument in the opposition:

1. **Identify the claim** - What is the opposition asserting?
2. **Map to opening brief** - Which opening argument does this respond to?
3. **Extract authorities** - What cases does opposition cite?
4. **Assess strength** - Strong (binding authority), Moderate (persuasive), Weak (distinguishable)

### Phase 3: Concession Identification

Search the opposition for:

**Explicit concessions:**
- "Plaintiff does not dispute..."
- "Defendant correctly notes..."
- Failure to address specific arguments

**Implicit concessions:**
- Arguments dropped from complaint defense
- Authorities not rebutted
- Facts not contested

**Critical requirement:** Every identified concession must include:
- Direct quotation from opposition
- Page citation (Opp. at [page])
- Confidence level (High/Medium) with explanation

### Phase 4: Standard of Review Check

Verify opposition correctly states the Twombly/Iqbal standard:

**Correct statement:**
> "To survive a motion to dismiss, a complaint must contain sufficient factual matter, accepted as true, to state a claim to relief that is plausible on its face."

**Common opposition misstatements to flag:**
- Conflating "plausible" with "possible"
- Omitting the "accepted as true" limitation to well-pleaded facts
- Ignoring that conclusory allegations are not entitled to presumption of truth

If misstated, note correction needed in reply.

### Phase 5: Leave to Amend Analysis

Assess whether the opposition:
- Requests leave to amend if motion granted
- Identifies what amendments would cure deficiencies
- Has prior amendment history

Evaluate futility arguments available.

### Phase 6: Prioritization and Outline

Categorize each opposition argument:

| Priority | Criteria | Action |
|----------|----------|--------|
| **Must Respond** | Strong authority, court likely to credit | Full rebuttal with counter-authority |
| **Should Respond** | Moderate strength, worth addressing | Concise rebuttal |
| **Ignore** | Weak, peripheral, or actually concedes | Do not dignify with response |

## Output Format

```markdown
## Opposition Analysis: [CASE NAME]

### Standard of Review Check
[Did opposition correctly state Twombly/Iqbal? Note any correction needed]

### Arguments Requiring Response (Priority 1)

#### OPP-1: [Argument title]
- **Summary:** [1-2 sentences]
- **Supporting Authority:** [Cases cited]
- **Responds to Opening Brief:** [Opening section/page]
- **Vulnerability:** [Weakness to exploit]
- **Recommended Response:** [Strategy]

### Arguments to Consider Addressing (Priority 2)
[Same structure]

### Arguments to Ignore
- **[Argument]** - Why: [Weak/peripheral/concedes point]

### Concessions to Highlight
> "[Direct quote from opposition]" (Opp. at [page])
- **Significance:** [Why this helps movant]
- **Confidence:** High/Medium [with explanation]

### Leave to Amend Analysis
- Amendment requested: [Yes/No]
- Would amendment cure deficiencies: [Analysis]
- Futility arguments: [Available grounds]
- Prior amendments: [History if any]

### Recommended Reply Structure
1. Introduction (1 paragraph)
2. [Section A: Primary argument]
3. [Section B: Secondary argument]
4. Conclusion with relief requested
```

## Quality Checklist

Before finalizing analysis:

- [ ] Every concession includes direct quotation with page citation
- [ ] Concession confidence levels assigned with explanation
- [ ] Standard of review verified against Twombly/Iqbal
- [ ] Argument lineage tracked (Opening -> Opposition -> Reply point)
- [ ] Leave to amend analysis included
- [ ] Priority categorization complete for all arguments

## References

- `references/opposition-analysis-checklist.md` - Detailed analysis checklist
- `references/concession-patterns.md` - Common concession language patterns
- `../litigation-skill-creator/references/key-authorities/pleading-standards.md` - Twombly/Iqbal framework

## Warnings

**Citation Verification Required:** All case citations identified in this analysis must be independently verified against original sources before relying on them in the reply brief. AI-generated analysis may mischaracterize holdings.

**Human Review Required:** This analysis is a starting point. Counsel must exercise independent judgment on argument prioritization and strategy.
