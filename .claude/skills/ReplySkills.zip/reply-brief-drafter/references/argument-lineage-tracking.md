# Argument Lineage Tracking

Critical safeguard ensuring reply briefs do not raise new arguments.

## Why Lineage Matters

Courts routinely strike reply brief sections that raise arguments not made in the opening brief. The rationale:

1. **Due process:** Opposing party has no opportunity to respond to new arguments in reply
2. **Procedural fairness:** Reply is for rebuttal, not new arguments
3. **Judicial efficiency:** Prevents endless briefing cycles

**Consequence of violation:** Court may strike the offending section, deny the motion, or sanction counsel.

## The Lineage Rule

**A reply argument is proper only if it:**

1. Was raised in the opening brief, AND
2. Is responding to something in the opposition

**A reply argument is improper (NEW) if:**

- It raises a theory not mentioned in the opening brief
- It cites authority for a proposition not argued in the opening
- It applies a legal standard not invoked in the opening
- It addresses facts or issues the opening did not raise

## Lineage Verification Process

### Step 1: Extract Opening Arguments

Create a table of every argument in the opening brief:

| ID | Opening Argument | Page(s) | Key Authority |
|----|------------------|---------|---------------|
| OB-1 | [Argument summary] | Mot. at 5-7 | [Case cited] |
| OB-2 | [Argument summary] | Mot. at 8-10 | [Case cited] |
| OB-3 | [Argument summary] | Mot. at 11-12 | [Case cited] |

### Step 2: Extract Opposition Arguments

Map each opposition argument to what it responds to:

| ID | Opposition Argument | Page(s) | Responds to |
|----|---------------------|---------|-------------|
| OP-1 | [Argument summary] | Opp. at 3-5 | OB-1 |
| OP-2 | [Argument summary] | Opp. at 6-8 | OB-2 |
| OP-3 | [Argument summary] | Opp. at 9-10 | OB-1, OB-3 |

### Step 3: Validate Reply Points

For each planned reply point, complete the lineage chain:

| Reply Point | Opening (OB-#) | Opposition (OP-#) | Status |
|-------------|----------------|-------------------|--------|
| [Reply argument 1] | OB-1 at 5 | OP-1 at 4 | ✓ VALID |
| [Reply argument 2] | OB-2 at 8 | OP-2 at 7 | ✓ VALID |
| [Reply argument 3] | ??? | OP-3 at 9 | ⚠️ NEW |

### Step 4: Resolve "NEW" Flags

When a reply point is flagged as NEW:

**Option A: Find the Opening Link**
- Search the opening brief more carefully
- The argument may be implicit in a broader point
- Check footnotes and background sections

**Option B: Reframe as Rebuttal**
- Rephrase the point as a response to opposition's error
- Focus on why opposition's argument fails
- Avoid introducing new legal theories

**Option C: Remove the Point**
- If no valid lineage exists, remove from reply
- Note for future motions if needed

## Common Lineage Violations

### Violation 1: New Legal Theory

**Opening:** "Plaintiff fails to plead scienter."
**Reply (improper):** "Plaintiff also fails to plead loss causation."

**Problem:** Loss causation is a new element, not raised in opening.

**Fix:** Remove unless loss causation was addressed in opening.

### Violation 2: New Authority

**Opening:** "Under *Smith v. Jones*, plaintiff's claim fails."
**Reply (improper):** "Additionally, *Brown v. Davis* supports dismissal."

**Problem:** *Brown* supports a new argument, not a response to opposition.

**Acceptable:** Citing *Brown* to rebut opposition's distinction of *Smith*.

### Violation 3: New Facts

**Opening:** "The complaint fails to allege defendant's knowledge."
**Reply (improper):** "The public filings attached hereto show defendant acted properly."

**Problem:** Introducing new facts through reply briefing.

**Fix:** Facts must be in complaint, incorporated by reference, or judicially noticeable.

### Violation 4: Scope Expansion

**Opening:** "Count I fails because plaintiff lacks standing."
**Reply (improper):** "Count I also fails because the claim is time-barred."

**Problem:** Statute of limitations is a new ground for dismissal.

**Fix:** Could only include if futility of amendment is at issue.

## Lineage Documentation Template

For each reply section, complete this documentation:

```markdown
### Reply Section [X]: [Title]

**Opening Brief Foundation:**
- Argument: [Summary of opening argument]
- Location: Mot. at [pages]
- Key quote: "[Quote establishing the argument]"

**Opposition Response:**
- Argument: [Summary of opposition response]
- Location: Opp. at [pages]
- Key quote: "[Quote being rebutted]"

**Reply Point:**
- Argument: [Summary of reply point]
- Type: [Rebuttal / Distinction / Concession highlight]

**Lineage Chain:**
Opening (Mot. at [X]) → Opposition (Opp. at [Y]) → Reply

**Status:** ✓ VALID / ⚠️ NEEDS REVIEW / ✗ NEW (remove)
```

## Borderline Cases

### Elaboration vs. New Argument

**Permitted:** Elaborating on an argument made in opening
**Prohibited:** Raising a fundamentally different point

**Test:** Would a reader of the opening brief recognize this as the same argument, just developed further in response to opposition?

### Authority in Reply

**Permitted:** Citing new cases to rebut opposition's cases
**Permitted:** Citing cases opposition cited for a different proposition
**Prohibited:** Citing cases for arguments not made in opening

### Responding to Opposition's New Points

**Permitted:** Explaining why opposition's new argument fails
**Prohibited:** Using opposition's new point as springboard for your own new argument

## Quality Checklist

Before finalizing reply:

- [ ] Every reply point has documented lineage to opening brief
- [ ] No legal theories appear in reply that were absent from opening
- [ ] New authorities cited only to rebut opposition's cases
- [ ] Facts cited are limited to complaint, incorporated documents, or judicial notice
- [ ] Scope of arguments has not expanded beyond opening

## Sample Lineage Table

Complete example for a motion to dismiss reply:

| # | Reply Point | Opening Ref | Opposition Ref | Status |
|---|-------------|-------------|----------------|--------|
| 1 | Plaintiff's standing argument fails | Mot. at 5-7 (standing section) | Opp. at 3-5 (standing rebuttal) | ✓ VALID |
| 2 | *Smith* case distinguishable | Mot. at 8 (citing *Smith*) | Opp. at 6 (discussing *Smith*) | ✓ VALID |
| 3 | Complaint is conclusory | Mot. at 9-11 (pleading analysis) | Opp. at 7-9 (sufficiency argument) | ✓ VALID |
| 4 | Opposition concedes key fact | Mot. at 10 (fact at issue) | Opp. at 8 (concession language) | ✓ VALID |
| 5 | Leave to amend futile | Mot. at 12 (requested dismissal with prejudice) | Opp. at 10 (leave to amend request) | ✓ VALID |

**Removed points (NEW argument):**
- "Statute of limitations bars claim" - Not raised in opening
- "Forum selection clause requires transfer" - Different motion entirely
