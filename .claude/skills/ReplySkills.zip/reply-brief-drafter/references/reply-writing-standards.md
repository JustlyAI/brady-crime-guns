# Reply Brief Writing Standards

Big Law quality standards for drafting reply briefs in support of motions to dismiss.

## Core Principles

### 1. Reply Briefs Are Different

Reply briefs are not:
- A second opening brief
- A comprehensive rebuttal of every opposition point
- An opportunity to raise new arguments

Reply briefs are:
- A surgical response to the opposition's strongest points
- A vehicle to highlight concessions and admissions
- The movant's final word

### 2. Less Is More

Reply briefs are typically limited (often 10 pages or less). Every sentence must earn its place. Cut aggressively.

### 3. Lead with Impact

Courts read the introduction carefully. Start strong with your best point or the opposition's most damaging concession.

## Paragraph Construction

### The Point-First Rule

Every paragraph must lead with its conclusion or main point. Never bury the lead.

**Bad:**
> When examining the various authorities cited by plaintiff, and considering the specific allegations in the complaint, which plaintiff asserts satisfy the pleading requirements, this Court should find that plaintiff has failed to state a claim.

**Good:**
> Plaintiff fails to state a claim. The complaint contains only conclusory allegations that parrot the statutory elements without factual support. (Compl. paras 15-17.)

### Paragraph Length

- Target: 3-5 sentences
- Maximum: 7 sentences
- Single-sentence paragraphs: Use sparingly for emphasis

### Sentence Variation

Mix sentence lengths for readability:

**Pattern:** Long (analysis) -> Short (punch) -> Medium (development)

> The opposition attempts to distinguish *Smith v. Jones* by arguing that the plaintiff there alleged a written contract. (Opp. at 5.) This distinction fails. The *Smith* court explicitly stated that its holding applies regardless of whether the contract is written or oral. 500 F.3d at 125.

## Transitions

### Banned Generic Transitions

Never use:
- "Moreover"
- "Furthermore"
- "Additionally"
- "In addition"
- "Also"
- "It is important to note"

### Substantive Transitions

Use transitions that advance the argument:

| Instead of | Use |
|------------|-----|
| "Moreover, the statute..." | "The statute's text confirms this reading..." |
| "Additionally, plaintiff..." | "Plaintiff compounds this error by..." |
| "Furthermore, courts..." | "Every circuit to address this issue..." |

### Transition Patterns

**Contrast:** "But the opposition ignores..."
**Building:** "This conclusion finds further support in..."
**Concession handling:** "Plaintiff's only response..."
**Case distinction:** "That case is readily distinguishable..."

## Tone and Voice

### Professional Confidence

Write with confidence but not arrogance. Let the analysis speak.

**Too aggressive:**
> Plaintiff's argument is absurd and ignores basic principles of law.

**Too timid:**
> It could perhaps be argued that plaintiff's position might not be fully supported.

**Just right:**
> Plaintiff's argument fails because it ignores the statutory text and contradicts binding precedent.

### Active Voice

Prefer active voice for clarity and directness.

**Passive (avoid):**
> It is argued by plaintiff that the contract was breached.

**Active (prefer):**
> Plaintiff argues the contract was breached.

### Attribution

Be precise about who is making arguments:
- "Plaintiff argues..." (opposition argument)
- "The complaint alleges..." (pleading content)
- "[DEFENDANT] demonstrated..." (opening brief)

## Citation Practices

### Citation Density

Every factual claim and legal proposition needs a citation. The target citation density for reply briefs:
- At least one citation per paragraph
- Every quotation cited
- Every case holding cited

### Citation Placement

**Integrated citations** (preferred for key points):
> The Supreme Court held in *Twombly* that "a formulaic recitation of the elements of a cause of action will not do." 550 U.S. at 555.

**Parenthetical citations** (for supporting points):
> Conclusory allegations are insufficient. (Compl. para 12.)

### Record Citations

Use consistent format:
- Complaint: `Compl. para [X]` or `Compl. at [page]`
- Opposition: `Opp. at [page]`
- Opening/Motion: `Mot. at [page]` or `Opening at [page]`
- Exhibits: `Ex. [X] at [page]`

### Case Citations

Bluebook format:
```
Party v. Party, [Vol] [Reporter] [Page], [Pin] ([Court] [Year])
Ashcroft v. Iqbal, 556 U.S. 662, 678 (2009)
```

Short form after first citation:
```
Iqbal, 556 U.S. at 679
```

## Handling Opposition Arguments

### Strong Arguments

Address head-on with counter-authority or distinction:

> Plaintiff relies primarily on *Smith v. Jones*, 100 F.3d 200 (9th Cir. 2020). That case is distinguishable because [specific distinction]. Here, by contrast, [application to facts].

### Weak Arguments

Dispatch quickly without elevating:

> Plaintiff's remaining arguments fail for the same reason: the complaint alleges conclusions, not facts.

### Concessions

Quote directly and use strategically:

> Plaintiff concedes the central point. As the opposition acknowledges, "[direct quote]." (Opp. at 5.) This admission is dispositive.

## What Not to Do

### Don't Repeat the Opening Brief

The court has read it. Reference it: "As explained in the opening brief (Mot. at 5-7)..."

### Don't Address Every Point

Ignore weak or peripheral arguments. Responding to everything dilutes focus.

### Don't Get Personal

Attack arguments, not counsel. Never:
- "Plaintiff's counsel misrepresents..."
- "Opposing counsel should know better..."
- "This disingenuous argument..."

### Don't Overstate

Avoid:
- "devastating" / "fatal" / "crushing"
- "clearly" / "obviously" / "undoubtedly"
- "slam dunk" / "smoking gun"

The analysis should demonstrate strength without adjectives.

## Editing Checklist

Before finalizing:

- [ ] Every paragraph leads with its point
- [ ] No generic transitions
- [ ] No banned words or phrases
- [ ] Active voice throughout
- [ ] Citation in every paragraph
- [ ] No repetition of opening brief text
- [ ] Word/page limit confirmed
- [ ] Concessions quoted exactly with cites
