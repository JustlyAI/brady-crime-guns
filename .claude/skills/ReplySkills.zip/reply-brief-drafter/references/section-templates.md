# Reply Brief Section Templates

Templates for each section of a reply brief in support of a motion to dismiss.

## Caption and Header

```
UNITED STATES DISTRICT COURT
[DISTRICT]

[PLAINTIFF(S)],
                              Plaintiff(s),

        v.                              Case No. [XX-cv-XXXXX-XXX]

[DEFENDANT(S)],
                              Defendant(s).

DEFENDANT [NAME]'S REPLY IN SUPPORT OF
MOTION TO DISMISS [PLAINTIFF'S/THE] [AMENDED] COMPLAINT
```

## Introduction Template

**Purpose:** Hook the court with the strongest point. Maximum 2 paragraphs.

### Pattern A: Lead with Concession

```markdown
[PLAINTIFF]'s Opposition confirms the motion should be granted. As plaintiff
concedes, "[direct quote from opposition]." (Opp. at [page].) This admission
is dispositive because [brief explanation of why it matters].

The Opposition fails to cure the complaint's deficiencies. [1-2 sentences
on what opposition got wrong]. For the reasons set forth below, the motion
should be granted [with prejudice / without leave to amend].
```

### Pattern B: Lead with Fatal Flaw

```markdown
[PLAINTIFF]'s Opposition does not—and cannot—cure the fatal defect in the
complaint: [state the core problem in one sentence]. Despite [X] pages of
argument, plaintiff never addresses [key missing element].

[DEFENDANT]'s Motion demonstrated that [restate core argument]. The
Opposition offers no response to this analysis. The motion should be granted.
```

### Pattern C: Standard of Review Correction

```markdown
[PLAINTIFF] fundamentally misstates the applicable legal standard. Under
*Twombly* and *Iqbal*, a complaint must allege facts—not conclusions—
sufficient to state a plausible claim. The Opposition's contention that
[misstatement] ignores this settled law.

When the proper standard is applied, the complaint fails. [Brief preview
of why]. The motion should be granted.
```

## Argument Section Templates

### Template 1: Rebutting Opposition Case Authority

**Use when:** Opposition relies on a case that can be distinguished.

```markdown
## I. [Descriptive Point Heading]

Plaintiff relies on [Case Name], [citation], for the proposition that
[state what opposition claims the case stands for]. (Opp. at [page].)
That case is distinguishable.

In [Case Name], the court addressed [specific factual scenario]. [Vol]
[Reporter] at [pincite]. The court held that [actual holding]. Id. at
[pincite]. Here, by contrast, [explain factual distinction].

[Case Name] does not help plaintiff for a second reason: [additional
distinction if available]. The [Case Name] court expressly noted that
"[limiting language from opinion]." Id. at [pincite].

Applying the correct standard, [DEFENDANT]'s position finds support in
[binding or more analogous authority]. See [Citation]. In [that case],
the court dismissed claims where [similar facts to this case]. [Brief
application].

Plaintiff's reliance on [Case Name] thus fails. The complaint does not
state a plausible claim for [cause of action].
```

### Template 2: Highlighting Implicit Concession

**Use when:** Opposition failed to address an argument from the opening brief.

```markdown
## II. [Descriptive Point Heading]

Plaintiff does not dispute that [state the point opposition failed to
address]. (Compare Mot. at [pages] with Opp. at [pages showing no response].)
This implicit concession resolves the issue.

The opening brief demonstrated that [restate argument briefly]. (Mot. at
[page].) Plaintiff offers no response. Courts routinely treat such silence
as concession. See [authority for treating silence as concession].

Even setting aside this concession, the argument fails on the merits.
[Brief substantive rebuttal if helpful]. The claim should be dismissed.
```

### Template 3: Addressing Weak Opposition Argument

**Use when:** Opposition argument is meritless and can be dispatched quickly.

```markdown
## III. [Descriptive Point Heading]

Plaintiff's remaining argument—that [summarize weak argument]—fails.

[One or two sentences explaining why it fails, with citation].

This argument requires no further response.
```

### Template 4: Complaint Allegations Insufficient

**Use when:** Opposition points to specific complaint allegations but they are conclusory.

```markdown
## IV. The Complaint's Allegations Are Conclusory

Plaintiff points to paragraphs [X-Y] of the complaint. (Opp. at [page].)
But these allegations are precisely the type of "formulaic recitation of
the elements" that *Twombly* and *Iqbal* hold insufficient.

Paragraph [X] alleges that "[quote conclusory allegation]." (Compl. ¶ [X].)
This is a legal conclusion, not a factual allegation. The complaint does
not allege [what specific facts are missing].

Paragraph [Y] fares no better. It alleges "[quote]." (Compl. ¶ [Y].) But
this allegation [explain why conclusory or implausible].

Conclusory allegations are "not entitled to the assumption of truth."
*Iqbal*, 556 U.S. at 679. Stripped of these conclusions, the complaint
fails to state a plausible claim.
```

### Template 5: Record Limitation at 12(b)(6)

**Use when:** Opposition relies on facts outside the complaint.

```markdown
## V. Plaintiff Improperly Relies on Facts Outside the Complaint

Plaintiff's argument depends on [facts not in complaint]. (Opp. at [page].)
But on a motion to dismiss, the Court may consider only the complaint,
documents incorporated by reference, and matters subject to judicial notice.

Plaintiff's assertions about [outside facts] appear nowhere in the complaint.
The Court cannot consider them. See [authority on 12(b)(6) record
limitations].

If plaintiff believes these facts support a claim, the proper course is to
file an amended complaint—not to introduce them through opposition briefing.
As currently pleaded, the complaint fails.
```

## Leave to Amend Section

### Template: Opposing Leave to Amend

```markdown
## VI. Leave to Amend Should Be Denied

Plaintiff requests leave to amend if the motion is granted. (Opp. at [page].)
Leave should be denied because amendment would be futile.

[If prior amendments exist:]
This is plaintiff's [second/third] attempt to plead a viable claim. Plaintiff
has already amended once [or more], yet the same deficiencies persist. See
[authority on denying leave after repeated failures].

[If deficiencies are incurable:]
The defect in plaintiff's claim is not a matter of pleading—it is a matter
of law. No additional factual allegations can cure [state the incurable
deficiency]. Amendment would therefore be futile.

[If public record contradicts plaintiff's theory:]
The public record establishes that [fact contradicting plaintiff's claim].
[Citation to judicially noticeable document]. Because any amendment
contradicting this record would be futile, leave should be denied.
```

### Template: Limiting Leave to Amend

```markdown
## VI. If Leave Is Granted, It Should Be Limited

If the Court is inclined to grant leave to amend, [DEFENDANT] respectfully
requests that leave be conditioned on [specific limitation]:

- Plaintiff must identify with particularity what new facts would be alleged
- Amendment must occur within [X] days
- [Other appropriate limitation]

This limitation is appropriate because [reason]. Courts regularly impose
such conditions. See [authority].
```

## Conclusion Template

**Length:** One paragraph, 3-5 sentences maximum.

### Standard Conclusion

```markdown
## Conclusion

For the foregoing reasons, [DEFENDANT] respectfully requests that the Court
grant its motion to dismiss [all claims in] the [Amended] Complaint with
prejudice [and without leave to amend].

Respectfully submitted,

[SIGNATURE BLOCK]
```

### Conclusion with Alternative Relief

```markdown
## Conclusion

For the foregoing reasons, [DEFENDANT] respectfully requests that the Court:

1. Grant the motion to dismiss Count [X] with prejudice;
2. Grant the motion to dismiss Counts [Y-Z] without prejudice; and
3. Deny plaintiff leave to amend [or: grant plaintiff leave to amend only
   as to Counts [Y-Z] within [X] days].

Respectfully submitted,

[SIGNATURE BLOCK]
```

## Signature Block Template

```
Dated: [Month Day, Year]

                              Respectfully submitted,

                              [FIRM NAME]

                              By: _______________________
                                  [Attorney Name]
                                  [Bar Number]
                                  [Address]
                                  [Phone]
                                  [Email]

                              Attorneys for Defendant
                              [DEFENDANT NAME]
```

## Word/Page Count Declaration

Some courts require a word count certification:

```
CERTIFICATE OF COMPLIANCE

I certify that this reply brief complies with the [X]-word limit set by
[Local Rule citation]. According to the word-count function of Microsoft
Word, this brief contains [X,XXX] words, excluding the caption, signature
block, and this certificate.

                              _______________________
                              [Attorney Name]
```

## Certificate of Service Template

```
CERTIFICATE OF SERVICE

I hereby certify that on [Month Day, Year], I caused a true and correct
copy of the foregoing DEFENDANT'S REPLY IN SUPPORT OF MOTION TO DISMISS
to be served on all counsel of record via the Court's CM/ECF system.

                              _______________________
                              [Attorney Name]
```
