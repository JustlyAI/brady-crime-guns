---
name: reply-brief-drafter
description: "Draft reply brief sections for motions to dismiss with Big Law quality standards. Use when: (1) drafting reply brief after opposition analysis, (2) writing reply sections from strategic outline, (3) need argument lineage tracking to prevent new arguments, (4) need record verification for 12(b)(6) compliance. Integrates with maite-legal-rewriter for prose quality and finalize-memo for formatting. Triggers on: 'draft reply', 'write reply brief', 'reply sections'."
---

# Reply Brief Drafter

Draft reply briefs in support of motions to dismiss with Big Law quality standards and verification safeguards.

## Prerequisites

Before invoking this skill, you should have:
- Strategic analysis from `reply-brief-analyzer`
- Opening motion to dismiss
- Opposition brief
- Complaint (for record verification)

## Workflow

### Phase 1: Setup and Verification

1. Load strategic analysis from `reply-brief-analyzer`
2. Confirm argument lineage for each reply point
3. Identify applicable word/page limits (check local rules)

### Phase 2: Argument Lineage Verification

**Critical safeguard:** Reply briefs cannot raise new arguments.

For each planned reply point, verify:

| Reply Point | Opening Brief | Opposition | Status |
|-------------|---------------|------------|--------|
| [Point] | Opening at [page] | Opp. at [page] | Valid/NEW |

Mark any point that cannot trace to both documents as **NEW ARGUMENT** and flag for removal or reconsideration.

### Phase 3: Record Verification (12(b)(6))

At 12(b)(6) stage, only these factual sources are proper:
- Allegations in the complaint (accepted as true)
- Documents attached to or incorporated by reference in complaint
- Matters subject to judicial notice

**Verification step:** For each factual assertion in the reply:
- [ ] Cite to complaint paragraph, OR
- [ ] Cite to incorporated document, OR
- [ ] Identify as judicially noticeable with authority

Flag any fact citing outside these sources.

### Phase 4: Draft Each Section

#### Introduction (1-2 paragraphs)

Lead with impact. Pattern:

```
[PLAINTIFF]'s Opposition confirms the motion should be granted.
[Key concession or fatal admission]. [Brief roadmap of reply:
2-3 sentences identifying main points].
```

#### Argument Sections (IRAC-lite)

For each Priority 1 and Priority 2 argument:

```
## [I. Descriptive Point Heading]

[ISSUE: One sentence framing the specific dispute]

[RULE: Controlling standard with citation]

To survive a motion to dismiss, a complaint must "state a claim
to relief that is plausible on its face." Ashcroft v. Iqbal,
556 U.S. 662, 678 (2009). [Additional rule if needed]

[APPLICATION: 2-4 paragraphs applying rule to opposition's
arguments. Highlight concessions. Cite to complaint and
opposition. Distinguish opposition's cases if needed.]

[CONCLUSION: 1-2 sentences stating why this claim fails]
```

#### Conclusion (1 paragraph)

```
For the foregoing reasons, [DEFENDANT] respectfully requests
that the Court grant its motion to dismiss [with/without]
prejudice [and without leave to amend because amendment
would be futile].
```

### Phase 5: Quality Review

Run through quality checklist before output.

## Writing Standards

### Paragraph Construction

- Lead with conclusions (no throat-clearing)
- Every assertion must be cited
- Paragraphs: 3-5 sentences max
- Vary sentence length: mix punchy with developed
- Strong topic sentences

### Banned Words

Eliminate entirely:
- delve, tapestry, vibrant, landscape, realm, embark
- excels, vital, comprehensive, intricate, pivotal
- moreover, arguably, notably, crucial
- establishing, effectively, significantly

### Banned Phrases

Eliminate entirely:
- "Dive into"
- "It's important to note"
- "Based on the information provided"
- "In conclusion" / "In summary"
- "The Court should note"

### Tone

- Professional confidence without hostility
- Respond to weak arguments concisely, not condescendingly
- Highlight concessions factually, without gloating
- Decisive language (avoid hedging when analysis supports position)

### Citation Format

Use Bluebook format:
- Cases: `Party v. Party, [Vol] [Reporter] [Page], [Pin] ([Court] [Year])`
- Record: `Compl. [paragraph]`, `Opp. at [page]`
- Opening: `Mot. at [page]` or `Opening at [page]`

## Quality Checklist

### Filing Requirements (Must Pass)

- [ ] Within page/word limit
- [ ] Caption correct
- [ ] Signature block present
- [ ] Certificate of service ready

### Substantive Verification (Critical)

- [ ] No new arguments (all points in lineage table)
- [ ] All facts cite to proper 12(b)(6) record
- [ ] All case citations flagged for human verification
- [ ] Concession quotes verified against opposition text
- [ ] Standard of review correctly stated

### Quality Standards

- [ ] Every assertion cited
- [ ] No banned words or phrases
- [ ] Topic sentences lead paragraphs
- [ ] Substantive transitions (not "Moreover," "Additionally")
- [ ] No repetition of opening brief language

## Integration

After drafting:

1. **Polish prose:** Invoke `maite-legal-rewriter` for Big Law quality
2. **Format:** Invoke `finalize-memo` for privilege headers and formatting

## References

- `references/reply-writing-standards.md` - Detailed writing guidance
- `references/section-templates.md` - Templates for each section
- `references/argument-lineage-tracking.md` - Lineage verification details
- `../maite-legal-rewriter/references/core-style.md` - Writing quality standards

## Warnings

**Citation Verification Required:** All case citations must be independently verified by human counsel against original sources. Do not rely on AI-generated citations without verification.

**Record Boundaries:** At 12(b)(6), the record is limited. Facts outside the complaint or incorporated documents will be stricken or cause conversion to summary judgment.

**New Argument Prohibition:** Courts routinely strike reply brief sections that raise arguments not made in the opening brief. The argument lineage table is a critical safeguard.
